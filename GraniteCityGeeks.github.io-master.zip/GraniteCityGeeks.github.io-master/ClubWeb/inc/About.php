<?php
include("scripts/header.php");
echo "
<main>
<h2>About Me</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eros quam,
pharetra ornare venenatis nec, eleifend vulputate dui. Phasellus a faucibus elit.
Vivamus sit amet porttitor quam. Nullam ut felis euismod, pulvinar felis a, mollis
sem. Praesent non magna hendrerit, hendrerit justo consequat, convallis mauris.
Donec accumsan eros nibh, non imperdiet libero tincidunt efficitur. Integer mattis
augue sed pulvinar fringilla. In mollis ultrices enim, nec porttitor risus viverra
luctus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames
ac turpis egestas. Nulla pretium sagittis ultrices. Nunc vel erat eu ante varius
rhoncus id ut libero. Vestibulum ut nunc rutrum, tempus arcu a, maximus dui.</p>
<p>Fusce ac faucibus odio, id malesuada nibh. Proin id blandit lectus. Suspendisse
potenti. Integer accumsan aliquet erat at faucibus. Aliquam sed tristique nisl.
Morbi at mi eu lacus rutrum facilisis nec eu diam. Mauris condimentum facilisis
sodales. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur
ridiculus mus.</p>
</main>
";
include("scripts/footer.php");
?>