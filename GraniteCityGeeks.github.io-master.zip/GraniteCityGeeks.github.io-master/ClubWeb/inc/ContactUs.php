<?php
include("scripts/header.php");
echo "
<main>
<h2>Contact</h2>
<p>Send me an email at babbage@babbage-labs.com</p>
</main>
";
include("scripts/footer.php");
?>