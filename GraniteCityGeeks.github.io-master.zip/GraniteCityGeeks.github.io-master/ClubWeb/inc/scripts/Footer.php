<footer>
    <p>(c)2016 - J.P Media</p>
</footer>